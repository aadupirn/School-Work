#include <stdio.h>
#include <inttypes.h>
#include <arpa/inet.h>
#include "CPU.h"

// to keep cache statistics
unsigned int accesses = 0;
unsigned int read_accesses = 0;
unsigned int write_accesses = 0;

#include "cache.h"

int main(int argc, char **argv)
{
    struct trace_item *tr_entry;
    size_t size;
    char *trace_file_name;
    int trace_view_on = 0;

    unsigned char t_type = 0;
    unsigned char t_sReg_a= 0;
    unsigned char t_sReg_b= 0;
    unsigned char t_dReg= 0;
    unsigned int t_PC = 0;
    unsigned int t_Addr = 0;

    unsigned int cycle_number = 0;

    if (argc == 1)
    {
        fprintf(stdout, "\nUSAGE: tv <trace_file> <switch - any character>\n");
        fprintf(stdout, "\n(switch) to turn on or off individual item view.\n\n");
        exit(0);
    }

    trace_file_name = argv[1];
    if (argc == 3) trace_view_on = atoi(argv[2]) ;
    FILE *config = fopen("cache_config.txt", "r");
    char line[256];
    // here you should extract the cache parameters from the configuration file (cache size, associativity, latency)
    fgets(line, sizeof(line), config);
    unsigned int L1size = atoi(line);
    fgets(line, sizeof(line), config);
    unsigned int bsize = atoi(line);
    fgets(line, sizeof(line), config);
    unsigned int L1assoc = atoi(line);
    fgets(line, sizeof(line), config);
    unsigned int L2size = atoi(line);
    fgets(line, sizeof(line), config);
    unsigned int L2assoc = atoi(line);
    fgets(line, sizeof(line), config);
    unsigned int L2_hit_latency = atoi(line);
    fgets(line, sizeof(line), config);
    unsigned int mem_latency = atoi(line);
    fclose(config);

    fprintf(stdout, "\n ** opening file %s\n", trace_file_name);

    trace_fd = fopen(trace_file_name, "rb");

    if (!trace_fd)
    {
        fprintf(stdout, "\ntrace file %s not opened.\n\n", trace_file_name);
        exit(0);
    }

    trace_init();
    struct cache_t *L1, *L2, *nextL;
    L1 = cache_create(L1size, bsize, L1assoc, 0);
    nextL = NULL;   // the next level in the hierarchy -- NULL indicates main memory
    if (L2size != 0)
    {
        L2 = cache_create(L2size, bsize, L2assoc, L2_hit_latency);
        nextL = L2;
    }

    while(1)
    {
        size = trace_get_item(&tr_entry);

        if (!size)
        {       /* no more instructions (trace_items) to simulate */
            printf("+ Simulation terminates at cycle : %u\n", cycle_number);
            printf("+ Cache statistics \n+ Write Accesses: %d\n+ Read Accesses: %d\n+ Accesses: %d\n", write_accesses, read_accesses, accesses);
            double L1missRate = ((double)L1->misses)/(L1->hits + L1->misses);
            printf("+ L1 Hits: %d\n+ L1 Misses %d\n",L1->hits, L1->misses);
            printf("+ L1 Miss Rate: %.2f%%\n", L1missRate*100);

            if(L2size != 0)
            {
                double L2missRate = ((double)L2->misses)/(L2->hits + L2->misses);
                printf("+ L2 Hits: %d\n+ L2 Misses %d\n",L2->hits, L2->misses);
                printf("+ L2 Miss Rate: %.2f%%\n", L2missRate*100);
            }
            break;
        }
        else
        {              /* parse the next instruction to simulate */
            cycle_number++;
            t_type = tr_entry->type;
            t_sReg_a = tr_entry->sReg_a;
            t_sReg_b = tr_entry->sReg_b;
            t_dReg = tr_entry->dReg;
            t_PC = tr_entry->PC;
            t_Addr = tr_entry->Addr;
        }

        switch(tr_entry->type)
        {
            case ti_NOP:
                if (trace_view_on) printf("[cycle %d] NOP:", cycle_number);
                break;
            case ti_RTYPE:
                if (trace_view_on)
                {
                    printf("[cycle %d] RTYPE:", cycle_number);
                    printf(" (PC: %x)(sReg_a: %d)(sReg_b: %d)(dReg: %d) \n", tr_entry->PC, tr_entry->sReg_a, tr_entry->sReg_b, tr_entry->dReg);
                }
                break;
            case ti_ITYPE:
                if (trace_view_on)
                {
                    printf("[cycle %d] ITYPE:", cycle_number);
                    printf(" (PC: %x)(sReg_a: %d)(dReg: %d)(addr: %x)\n", tr_entry->PC, tr_entry->sReg_a, tr_entry->dReg, tr_entry->Addr);
                }
                break;
            case ti_LOAD:
                if (trace_view_on)
                {
                    printf("[cycle %d] LOAD:", cycle_number);
                    printf(" (PC: %x)(sReg_a: %d)(dReg: %d)(addr: %x)\n", tr_entry->PC, tr_entry->sReg_a, tr_entry->dReg, tr_entry->Addr);
                }
                accesses++;
                read_accesses++;
                cycle_number = cycle_number + cache_access(L1, tr_entry->Addr, 'r', cycle_number, nextL, mem_latency, '1');
                break;
            case ti_STORE:
                if (trace_view_on)
                {
                    printf("[cycle %d] STORE:", cycle_number);
                    printf(" (PC: %x)(sReg_a: %d)(sReg_b: %d)(addr: %x)\n", tr_entry->PC, tr_entry->sReg_a, tr_entry->sReg_b, tr_entry->Addr);
                }
                accesses++;
                write_accesses++;
                cycle_number = cycle_number + cache_access(L1, tr_entry->Addr, 'w', cycle_number, nextL, mem_latency, '1');
                break;
            case ti_BRANCH:
                if (trace_view_on)
                {
                    printf("[cycle %d] BRANCH:", cycle_number);
                    printf(" (PC: %x)(sReg_a: %d)(sReg_b: %d)(addr: %x)\n", tr_entry->PC, tr_entry->sReg_a, tr_entry->sReg_b, tr_entry->Addr);
                }
                break;
            case ti_JTYPE:
                if (trace_view_on)
                {
                    printf("[cycle %d] JTYPE:", cycle_number);
                    printf(" (PC: %x)(addr: %x)\n", tr_entry->PC, tr_entry->Addr);
                }
                break;
            case ti_SPECIAL:
                if (trace_view_on) printf("[cycle %d] SPECIAL:", cycle_number);
                break;
            case ti_JRTYPE:
                if (trace_view_on)
                {
                    printf("[cycle %d] JRTYPE:", cycle_number);
                    printf(" (PC: %x) (sReg_a: %d)(addr: %x)\n", tr_entry->PC, tr_entry->dReg, tr_entry->Addr);
                }
                break;
        }

    }
    trace_uninit();

    exit(0);
}
